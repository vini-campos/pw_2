<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teste</title>
    <link rel="stylesheet" href="exemplo.css">

    <style>
        h1{
            color: rgb(24, 12, 250);
        } 
    </style>
    
</head>

<body>
    <h1>Variáveis e constantes PHP</h1>
    <?php
        //variável
        /*
        
        */
        $a = 2;  //int
        $b = 1.1; //float
        $c = "a"; //string
        $d = 'a'; //string
        $e = null; //nulo
        $f = false; //bool
        
        //CONSTANTE
        define('MINHA_CONST', "Teste");
        const Teste = "adalberto";
        //Escreverndo na tela
        echo "o valor de \$A é " . $a;
        echo "\t<p>o valor de B é $b</p>\n";
        echo '\t<p>o valor de B é $b</p>\n';
        print "\t<p>o valor de A + B é " . $a + $b . "</p>\n";

        echo "O valor de const é " . Teste;

        //Objeto DateTime
        $d = new DateTime("now",
         new DateTimeZone("America/Sao_Paulo"));
        echo "\t<p>A data e hora atual é {$d->format("d/m/Y - H:i:s")}</p>\n";

    ?>
    
    <h1>Estruturas de decisão</h1>
    <?php
        if($a > $b){
            echo "\t<p>Verdade</p>";
        } elseif($a == $b || $b < $c){
            echo "\t<p>A é igual a B</p>\n";
        }
        //while($a > $b){ echo "\t<p>Teste</p>\n";}
    ?>

    <h2>Switch</h2>

    <?php
        switch($variable){
            
        }
    ?>
</body>

</html>